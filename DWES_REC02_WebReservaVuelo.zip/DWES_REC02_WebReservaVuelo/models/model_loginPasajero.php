<?php
    require_once("../db/db.php");

    function dameUsuario($fechNac,$email)  {
        global $conexion;
        try {

            $sql=("SELECT passenger_id,name,birthdate,emailaddress from passengerdetails where birthdate='$fechNac' and emailaddress ='$email' ");
            $statement = $conexion->prepare($sql);
            $statement->bindParam(":birthdate", $fechNac);
            $statement->bindParam(":emailaddress", $email);
            $statement->execute();
            $resultado=$statement->fetch(PDO::FETCH_ASSOC);
            return $resultado;
            
        }   catch (PDOException $ex) {
            echo "<strong>ERROR: </strong> ". $ex->getMessage();
        }

    }
?>