<?php

require_once("../db/db.php");


//Funcion que devuelve vuelos con plazas disponibles

function dameVuelosPlazasDisponibles()
{

    $informacionVuelos = dameVuelos();

    for ($i = 0; $i < count($informacionVuelos); $i++) {

        $informacionVuelo = $informacionVuelos[$i];
        $plazasDisponibles = (string)plazasDisponibles($informacionVuelo);
        $informacionVuelos[$i]['capacity'] = $plazasDisponibles;
    }

    return $informacionVuelos;
}

//Funcion que devuelve el numero de plazas disponibles

function plazasDisponibles($informacionVuelo)
{

    $capacidadAvion = $informacionVuelo['capacity'];
    $numeroPasajerosPorVuelo = numeroPasajerosPorVuelo($informacionVuelo['flight_id']);
    $plazasDisponibles = $capacidadAvion - $numeroPasajerosPorVuelo['numeroPasajeros'];
    return $plazasDisponibles;
}

//Funcion que recoge informacion del vuelo y capacidad del avión

function dameVuelos()
{
    global $conexion;
    try {
        $sql = ("SELECT flight.flight_id,flight.flightno,flight.from_a,flight.to_a,flight.departure,
                    flight.arrival,flight.airline_id, flight.airplane_id,airplane.capacity from 
                    flight,airplane WHERE airplane.airplane_id = flight.airplane_id");
        $statement = $conexion->prepare($sql);
        $statement->execute();
        $resultado = $statement->fetchAll(PDO::FETCH_ASSOC);
        return $resultado;
    } catch (PDOException $ex) {
        echo "<strong>ERROR: </strong> " . $ex->getMessage();
    }
}


//Esta consulta devuelve el numero de pasajeros por vuelo

function numeroPasajerosPorVuelo($idVuelo)
{
    global $conexion;
    try {
        $sql = ("SELECT flight.flight_id, COUNT(booking.passenger_id) AS numeroPasajeros FROM booking,flight
             WHERE flight.flight_id = booking.flight_id
                 AND flight.flight_id = '$idVuelo'
             GROUP BY booking.flight_id");
        $statement = $conexion->prepare($sql);
        $statement->execute();
        $resultado = $statement->fetch(PDO::FETCH_ASSOC);
        return $resultado;
    } catch (PDOException $ex) {
        echo "<strong>ERROR: </strong> " . $ex->getMessage();
    }
}



//Esta consulta devuelve la capacidad de cada avion

function capacidadAvion()
{
    global $conexion;
    try {
        $sql = ("SELECT capacity,flight.airplane_id FROM airplane,flight WHERE airplane.airplane_id = flight.flight_id");
        $statement = $conexion->prepare($sql);
        $statement->execute();
        $resultado = $statement->fetchAll(PDO::FETCH_ASSOC);
        return $resultado;
    } catch (PDOException $ex) {
        echo "<strong>ERROR: </strong> " . $ex->getMessage();
    }
}
