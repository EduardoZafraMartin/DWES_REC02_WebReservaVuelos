<?php

require_once("../db/db.php");

function borrarReserva($flight_id,$passenger_id)  {
    global $conexion;
    try {

        $sql=("DELETE from booking where flight_id='$flight_id' and passenger_id ='$passenger_id'");
        $statement = $conexion->prepare($sql);
        $statement->bindParam(":birthdate", $fechNac);
        $statement->bindParam(":emailaddress", $email);
        $statement->execute();
        $resultado=$statement->fetch(PDO::FETCH_ASSOC);
        return $resultado;
        
    }   catch (PDOException $ex) {
        echo "<strong>ERROR: </strong> ". $ex->getMessage();
    }

}



?>