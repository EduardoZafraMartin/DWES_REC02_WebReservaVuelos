<?php
    require_once("../db/db.php");

    function damePrecioBillete($flight_id) {
        
        global $conexion;

        try {

            $query = "select * from airplane where airplane_id = (select airplane_id from flight where 
                      flight_id = '$flight_id')";
            $obtenerCapacidad = $conexion->prepare($query);
            $obtenerCapacidad->execute();
            $resultado = $obtenerCapacidad->fetch(PDO::FETCH_ASSOC);
            if ($resultado['capacity']<100){
                return 80;
            }else if($resultado['capacity']>=100 && $resultado['capacity']<=200){
                return 120;
            }else{
                return 300;
            }
            
        } catch (PDOException $ex) {
            echo $ex->getMessage();
        }
    }
    
?>