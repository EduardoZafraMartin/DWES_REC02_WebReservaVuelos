<?php
  
   session_start();

   include '../models/apiRedsys.php';
   
   if (isset($_SESSION['RESERVAS_VUELOS'])) {
      
       $_SESSION['RESERVAS_VUELOS'] = array();
      
        header("location: ../views/view_inicioPasajero.php");
    }
