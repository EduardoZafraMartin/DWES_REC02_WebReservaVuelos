<?php
    require_once('../views/view_loginPasajero.php');
    require_once ('../models/model_loginPasajero.php');
    

    $email=$_POST['user'];
    $fechNac=$_POST['password'];
    $resultado = dameUsuario($fechNac,$email);
    if ($resultado['birthdate'] == $fechNac && $resultado['emailaddress'] == $email){
        session_start();
        $_SESSION['birthdate']=$resultado['birthdate'];
        $_SESSION['name']=$resultado['name'];
        $_SESSION['emailaddress']=$resultado['emailaddress'];
        $_SESSION['passenger_id']=$resultado['passenger_id'];
        $_SESSION['logueado']=true;
        header("location: ../views/view_inicioPasajero.php");

    }else{
        echo ("Usuario o contraseña incorrecto");
        
    }

   