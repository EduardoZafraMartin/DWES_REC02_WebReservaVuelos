<?php
    require_once ('../models/model_registroPasajero.php');

    $id=$_POST['idPasajero'];
    $nombre=$_POST['name'];
    $fechaNacimiento=$_POST['fechNac'];
    $sexo=$_POST['sexo'];
    $calle=$_POST['calle'];
    $ciudad=$_POST['ciudad'];
    $codigoPostal=$_POST['codPostal'];
    $pais=$_POST['pais'];
    $email=$_POST['email'];
    $telefono=$_POST['telefono'];

    if (altaPasajero($id,$nombre,$fechaNacimiento,$sexo,$calle,$ciudad,$codigoPostal,$pais,$email,$telefono)){

        echo "Se ha dado de alta correctamente";

    }else{

        echo "Se ha dado de alta correctamente";
    }
  

    require_once("../views/view_registroPasajero.php");
