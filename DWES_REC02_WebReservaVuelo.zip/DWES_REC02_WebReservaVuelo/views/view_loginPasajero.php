<html>
   
   <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Web Reservas Vuelos</title>
    </head>
      
     <body>
    <h1 class="text-center">Web Reservas Vuelos</h1>

    <div class="container ">
        <!--Aplicacion-->
		<div class="card border-success mb-3" style="max-width: 30rem;">
		<div class="card-header"><h2>Login pasajero</h2></div>
		<div class="card-body">
		
		<form action= "../controllers/controllers_loginPasajero.php" method="post" class="card-body">
		
		<div class="form-group">
			Usuario <input type="text" name="user" placeholder="Email" class="form-control"> <br><br>
        </div>
		<div class="form-group">
			Clave <input type="password" name="password" placeholder="Fecha de Nacimiento" class="form-control"><br><br>
        </div>				
        
		<input type="submit" name="submit" value="Login" class="btn btn-warning disabled">
        </form>
		
	    </div>
    </div>
    </div>
    </div>
    <p> Para volver al INDEX pulse <a href="../index.html">AQUI</a></p>


</body>
</html>