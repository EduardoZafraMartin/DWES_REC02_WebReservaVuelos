<?php
    if(!isset ($_SESSION)){
        session_start();
    }

    if(!isset ($_SESSION ['logueado']) || ($_SESSION ['logueado'] ==false)){
        header("location: view_loginEmpleado.php");
    }
?>
<html>
    <body>
    <head>
        <style type="text/css">
            div {
        background-color: #d8da3d;
        width: 350px;
        text-align:center;
        }
  </style>
    </head>
    <div>
        <p>Bienvenido <?php echo $_SESSION['name'];?></p>
    </div>
    
   
    <form name="from" action="https://sis-t.redsys.es:25443/sis/realizarPago" method="POST">
        <input type="hidden" name="Ds_SignatureVersion" value="HMAC_SHA256_V1"/>
        <input type="hidden" name="Ds_MerchantParameters" value="<?php echo $_SESSION['merchantParametersEncriptados'] ?>"/>
        <input type="hidden" name="Ds_Signature" value="<?php echo $_SESSION['claveComercio'] ?>"/>
        <input type="submit" name="aniadirSaldo" value="Confirmar Reserva">	
    </form>         
        <ul>
        <li><a href="../views/view_inicioPasajero.php">Volver a menu</a></li>
        <li><a href="../views/view_logout.php">Cerrar Sesion</a></li>
        </ul>
    </body>
</html>