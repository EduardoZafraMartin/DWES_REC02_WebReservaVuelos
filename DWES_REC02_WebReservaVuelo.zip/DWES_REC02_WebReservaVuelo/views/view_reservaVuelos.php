<?php
if (!isset($_SESSION)) {
    session_start();
}

if (!isset($_SESSION['logueado']) || ($_SESSION['logueado'] == false)) {
    header("location: view_loginPasajero.php");
}
?>
<html>

<body>

    <head>
        <style type="text/css">
            div {
                background-color: #d8da3d;
                width: 243px;
                height: 30px;
                text-align: center
            }
        </style>
    </head>

    <form method="POST" action="../controllers/controller_reservaVuelos.php">
        <div>
            <p>Bienvenido <?php echo $_SESSION['name']; ?></p><br>
        </div>
        <p>
        <h2>Reservar Vuelos</h2>
        </p>
        
        <?php foreach ($_SESSION['RESERVAS_VUELOS'] as $vueloReservado) : ?>
            <?php echo ("El vuelo con ID " . $vueloReservado . " ha sido seleccionado"); ?><br>
            <?php endforeach; ?><br><br>
        <label for="form">Elige el vuelo </label>
        <select name="vueloSeleccionado" style="text-align:left;color: red;background: #f0f0f0;" required>
            <?php foreach ($vuelos as $vuelo) : ?>
                <?php echo '<option value="' . $vuelo['flight_id'] . '"> idVuelo ' . $vuelo['flight_id'] .' flightno ' . $vuelo['flightno'] . 
                ' from ' . $vuelo['from_a'] . ' to ' . $vuelo['to_a'] .' departure ' . $vuelo['departure'] . ' arrival ' . $vuelo['arrival'] .
                ' idAirline ' . $vuelo['airline_id'] .  ' plazasDisponibles ' . $vuelo['capacity'] . '</option>'; ?>
            <?php endforeach; ?>
        </select><br><br>
        <input type="submit" name="reservarVuelo" value="Reservar vuelo">
        <input type="submit" name="finalizarReserva" value="Finalizar Reserva">
    </form>
    

    <ul>
        <li><a href="../views/view_inicioPasajero.php">Volver a menu</a></li>
    </ul>

</body>

</html>