<?php
if (!isset($_SESSION)) {
    session_start();
}

if (!isset($_SESSION['logueado']) || ($_SESSION['logueado'] == false)) {
    header("location: view_loginPasajero.php");
}
?>
<html>

<body>

    <head>
        <style type="text/css">
            div {
                background-color: #d8da3d;
                width: 243px;
                height: 30px;
                text-align: center
            }
        </style>
    </head>

    <form method="POST" action="../controllers/controller_checkIn.php">
        <div>
            <p>Bienvenido <?php echo $_SESSION['name']; ?></p><br>
        </div>
        <p>
        <h2>Check-In</h2>
        </p>
        <label for="form">Elige el vuelo </label>
        <select name="vueloReservado" style="text-align:left;color: red;background: #f0f0f0;" required>
            <?php foreach ($reservaVuelos as $vuelo) : ?>
                <?php $datos = $vuelo['flight_id'] . "a" . $vuelo['booking_id'];echo '<option value="' . $datos . '"> Vuelo ' . $vuelo['flightno'] .' Origen ' . $vuelo['origen'] . 
                ' Destino ' . $vuelo['destino'] . '</option>'; ?>
            <?php endforeach; ?>
        </select><br><br>
        <input type="submit" name="reservarVuelo" value="Chek-in">
    </form>
    

    <ul>
        <li><a href="../views/view_inicioPasajero.php">Volver a menu</a></li>
    </ul>

</body>

</html>