<?php
if (!isset($_SESSION)) {
    session_start();
}

if (!isset($_SESSION['logueado']) || ($_SESSION['logueado'] == false)) {
    header("location: view_loginPasajero.php");
}
?>
<html>

<body>

    <head>
        <style>
            table, td, th {
            border: 1px solid black;
            background-color:aquamarine;
            text-align: center
            }
            table {
            border-collapse: collapse;  
            width: 50%;
            }
            div {
            background-color: #d8da3d;
            width: 350px;
            text-align: center
            }

        </style>
    </head>

    <form method="POST" action="../controllers/controller_consultarReserva.php">
        <div>
            <p>Bienvenido/a <?php echo $_SESSION['name']; ?></p><br>
        </div>
        <p>
        <h2>Consular Reserva</h2>
        </p>
        <label for="form">Vuelos Reservados</label>
        <select name="vueloReservado" style="text-align:left;color: red;background: #f0f0f0;" required>
        <?php foreach ($reservaVuelos as $vuelo) : ?>
                <?php $datos = $vuelo['flight_id'] . "a" . $vuelo['booking_id'];echo '<option value="' . $datos . '"> Vuelo ' . $vuelo['flightno'] .' Origen ' . $vuelo['origen'] . 
                ' Destino ' . $vuelo['destino'] . ' ID Reserva ' . $vuelo['booking_id'] . '</option>'; ?>
            <?php endforeach; ?>
        </select><br><br>
        <input type="submit" name="consultar" value="Consultar Reserva">
    </form>

    
    <?php 
        if (isset($_POST['consultar'])){
            ?>
            <table>
                <tr><td>Nombre Pasajero</td><td>Origen</td><td>Destino</td><td>Numero Vuelo</td><td>Fecha Salida</td><td>Fecha Entrada</td><td>Numero Reserva</td><td>Asiento</td><td>Precio Reserva</td></tr>
                    <?php foreach ($infoReservas as $reserv) : ?>
                    <?php echo '<tr><td>' .  $reserv['name'] . '</td><td>' . $reserv['origen'] . '</td><td>' . $reserv['destino'] . '</td><td>' . $reserv['flightno'] . '</td><td>' . $reserv['departure'] . '</td><td>'
                    . $reserv['arrival'] . '</td><td>' . $reserv['booking_id'] . '</td><td>' . $reserv['seat'] . '</td><td>' . $reserv['price'] . '</td><td>' . '</td></tr>'; ?>
                    <?php endforeach; ?>
            </table>
            <?php
        }
    ?>
    

    <ul>
        <li><a href="../views/view_inicioPasajero.php">Volver a menu</a></li>
    </ul>

</body>

</html>