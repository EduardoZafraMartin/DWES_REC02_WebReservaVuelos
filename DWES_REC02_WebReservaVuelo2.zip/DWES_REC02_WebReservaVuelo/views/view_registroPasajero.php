<html>
<body>
    <p>
    <h1>Registro pasajero</h1>
    </p>
    <form action="../controllers/controller_registroPasajero.php" method="POST">
        <input type="number" name="idPasajero">ID pasajero</input><br><br>
        <input type="text" name="name">Nombre</input><br><br>
        <input type="date" name="fechNac">Fecha nacimiento</input><br><br>
        <input type="text" name="sexo">Sexo</input><br><br>
        <input type="text" name="calle">Direccion (Calle)</input><br><br>
        <input type="text" name="ciudad">Ciudad</input><br><br>
        <input type="number" name="codPostal">Codigo postal</input><br><br>
        <input type="text" name="pais">Pais</input><br><br>
        <input type="email" name="email">Email</input><br><br>
        <input type="number" name="telefono">Telefono</input><br><br>
        <input type="submit" name="alta" value="registrar"><br><br>
        <a href="../views/view_loginPasajero.php">Login pasajero</a>
    </form>
</body>

</html>