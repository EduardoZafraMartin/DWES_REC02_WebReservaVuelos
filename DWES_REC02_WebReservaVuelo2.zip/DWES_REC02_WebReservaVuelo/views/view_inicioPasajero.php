<?php
    if(!isset ($_SESSION)){
        session_start();
    }

    if(!isset ($_SESSION ['logueado']) || ($_SESSION ['logueado'] ==false)){
        header("location: view_loginPasajero.php");
    }
?>
<html>
    <head>
        <style type="text/css">
            div {
        background-color: #d8da3d;
        width: 200px;
        text-align: center
        }
    </style>
    </head>

    <body>
        <div>
            <p>Bienvenido/a <?php echo $_SESSION['name'];?></p>
        </div>
   
        <p><h2>Menu pasajero</h2></p>
        <ul>
        <li><a href="../controllers/controller_reservaVuelos.php"">Reserva Vuelos</a></li>
        <li><a href="../controllers/controller_checkIn.php">Check-in Vuelos</a></li>
        <li><a href="../controllers/controller_consultarReserva.php">Consultar Reserva</a></li>
        <li><a href="view_logout.php">Cerrar Sesion</a></li>
        </ul>
    </body>
</html>