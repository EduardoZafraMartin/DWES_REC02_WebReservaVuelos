<?php
    require_once ('../models/model_registroPasajero.php');

    $id=$_POST['idPasajero'];
    $nombre=$_POST['name'];
    $fechaNacimiento=$_POST['fechNac'];
    $sexo=$_POST['sexo'];
    $calle=$_POST['calle'];
    $ciudad=$_POST['ciudad'];
    $codigoPostal=$_POST['codPostal'];
    $pais=$_POST['pais'];
    $email=$_POST['email'];
    $telefono=$_POST['telefono'];

    $idPasajero = idPasajero($id);
    if($idPasajero ==false){
        if (validaEntrada($id,$nombre,$fechaNacimiento,$sexo,$calle,$ciudad,$codigoPostal,$pais,$email,$telefono)){
            altaPasajero($id,$nombre,$fechaNacimiento,$sexo,$calle,$ciudad,$codigoPostal,$pais,$email,$telefono);
    
            echo "Se ha dado de alta correctamente. ";
    
        }else{
    
            echo " NO se ha dado de alta correctamente. ";
        }

    }else{
        
        echo "El ID ya existe.";
    }
    

   
  

    require_once("../views/view_registroPasajero.php");
