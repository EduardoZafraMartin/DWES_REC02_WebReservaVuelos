<?php

require ('../models/model_checkIn.php');


session_start();


    $idPasajero=$_SESSION['passenger_id'];
    $reservaVuelos = dameReservas($idPasajero);
    require_once("../views/view_checkIn.php");

    if(isset($_POST['vueloReservado'])){
        $vuelo = explode("a",$_POST['vueloReservado']);
        $vueloReservado = $vuelo[0];   
        $bookingId = $vuelo[1]; 
        $capacidadAvion=capacidadAvion($vueloReservado);
        $arrayAsientos=arrayAsientos($vueloReservado,$idPasajero);
        $numeroEncontrado = 1;
        $numeroAsiento=0;

        do{
            $capacidad = $capacidadAvion[0];
            $numeroRandom=dameNumeroRandom(intval($capacidad['capacity']));
            for ($i=0; $i < count($arrayAsientos); $i++) { 
                
                if($numeroRandom == $arrayAsientos[$i]){

                    $numeroEncontrado = 0;
                } 
            }
            $numeroAsiento = $numeroRandom;
            
        }while ($numeroEncontrado == 0);


        asignarAsiento($numeroAsiento,$idPasajero,$bookingId,$vueloReservado);

        echo ("Check in realizado correctamente. Su asiento es el " . $numeroAsiento);
    }  

   

?>