<?php
  
   session_start();

   if(isset($_SESSION['RESERVAS_VUELOS'])){

        

   }
   
       header("location: ../views/view_reservaVuelos.php");
       
?>