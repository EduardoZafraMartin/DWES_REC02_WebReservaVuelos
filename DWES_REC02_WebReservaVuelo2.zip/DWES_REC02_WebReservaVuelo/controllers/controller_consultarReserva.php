<?php
    require ('../models/model_checkIn.php');
    require ('../models/model_consultarReserva.php');
    
    session_start();

    $idPasajero=$_SESSION['passenger_id'];
    $reservaVuelos = dameReservas1($idPasajero);
    
    if (isset($_POST['vueloReservado'])) {
        $idVuelo = $_POST['vueloReservado'];
        $vuelo = explode("a",$_POST['vueloReservado']);
        $vueloReservado = $vuelo[0];   
        $bookingId = $vuelo[1]; 
        $infoReservas = dameReserva($vueloReservado,$idPasajero,$bookingId);
        
    }

    

    require_once('../views/view_consultarReserva.php');
?>