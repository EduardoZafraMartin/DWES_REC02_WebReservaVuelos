<?php

require_once("../db/db.php");

    function altaPasajero($id,$nombre,$fechaNacimiento,$sexo,$calle,$ciudad,$codigoPostal,$pais,$email,$telefono) {
        global $conexion;

        try {
            $obtenerID = $conexion->prepare("INSERT into passengerdetails (passenger_id,name,birthdate,sex,street,city,zip,country,emailaddress,telephoneno)
                                             values ('$id','$nombre','$fechaNacimiento','$sexo','$calle','$ciudad','$codigoPostal','$pais','$email','$telefono')");
            $obtenerID->execute();
            
        //return $obtenerID->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $ex) {
            echo $ex->getMessage();
        }
    }

    function idPasajero($id) {
        global $conexion;

        try {
            $obtenerID = $conexion->prepare("SELECT passenger_id from passengerdetails where passenger_id = '$id'");
            $obtenerID->execute();
            
            return $obtenerID->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $ex) {
            echo $ex->getMessage();
        }
    }


    function validaEntrada($id,$nombre,$fechaNacimiento,$sexo,$calle,$ciudad,$codigoPostal,$pais,$email,$telefono){

        //Validamos si algún campo del registro está vacio
        if(empty($id) || empty($nombre) ||empty($fechaNacimiento)|| empty($sexo) || empty($calle) || empty($ciudad) ||empty($codigoPostal)|| empty($pais)
        ||empty($email)|| empty($telefono)) {
            
          echo "Hay campos vacios.";
          return false;
        }else{
            return true;
        }
        
    }
?>