<?php

require_once("../db/db.php");



function dameReservas($idPasajero){

    global $conexion;
    try {
        $sql = ("SELECT a1.name origen,a2.name destino,flight.flight_id,flight.flightno,flight.from_a,flight.to_a,flight.departure,
                    flight.arrival,flight.airline_id, flight.airplane_id , booking.booking_id from 
                    flight,booking,airport a1, airport a2 WHERE booking.flight_id = flight.flight_id AND 
                    flight.from_a = a1.airport_id AND flight.to_a = a2.airport_id AND passenger_id = '$idPasajero'  AND booking.seat IS NULL");
        $statement = $conexion->prepare($sql);
        $statement->execute();
        $resultado = $statement->fetchAll(PDO::FETCH_ASSOC);
        return $resultado;
    } catch (PDOException $ex) {
        echo "<strong>ERROR: </strong> " . $ex->getMessage();
    }
}


//Capacidad del avion en funcion de su flight_id

function capacidadAvion($flight_id)
{
    global $conexion;
    try {
        $sql = ("SELECT capacity,flight.airplane_id FROM airplane,flight WHERE airplane.airplane_id = flight.airplane_id AND flight.flight_id ='$flight_id';");
        $statement = $conexion->prepare($sql);
        $statement->execute();
        $resultado = $statement->fetchAll(PDO::FETCH_ASSOC);
        return $resultado;
    } catch (PDOException $ex) {
        echo "<strong>ERROR: </strong> " . $ex->getMessage();
    }
}

// Funcion que da numero random

function dameNumeroRandom($capacidad){

    $asiento=rand(1,$capacidad);
    return $asiento;
}

function arrayAsientos($flight_id,$passenger_id){
    global $conexion;
    try {
        $sql = ("SELECT seat FROM booking WHERE flight_id ='$flight_id' AND passenger_id = '$passenger_id';");
        $statement = $conexion->prepare($sql);
        $statement->execute();
        $resultado = $statement->fetchAll(PDO::FETCH_ASSOC);
        return $resultado;
    } catch (PDOException $ex) {
        echo "<strong>ERROR: </strong> " . $ex->getMessage();
    }

    
}

function asignarAsiento($asiento,$passengerId,$bookingId,$flightId){
    global $conexion;
    try {
    $sql=("UPDATE booking SET seat = '$asiento' WHERE passenger_id='$passengerId' AND booking_id = '$bookingId' AND flight_id = '$flightId';");
    $statement = $conexion->prepare($sql);
    $statement->execute();
    }catch (PDOException $ex) {
        echo "<strong>ERROR: </strong> ". $ex->getMessage();
    }
}

?>