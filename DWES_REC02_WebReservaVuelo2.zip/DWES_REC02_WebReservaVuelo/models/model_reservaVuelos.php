<?php
    require_once("../db/db.php");

    function realizarReserva($flight_id,$passenger_id,$price) {
        
        global $conexion;

        try {
            $query = "INSERT into booking
            (flight_id,passenger_id,seat,price) values ('$flight_id','$passenger_id',
            null,'$price')";
            $obtenerID = $conexion->prepare($query);
            $obtenerID->execute();

        } catch (PDOException $ex) {
            echo $ex->getMessage();
        }
    }

    
?>