<?php

require_once("../db/db.php");

    function dameReserva($flight_id,$passenger_id,$booking_id){
        global $conexion;
        try {
            $sql=("SELECT a1.name origen,a2.name destino,flight.flightno,flight.departure,flight.arrival, booking.booking_id,booking.price, 
            booking.seat,passengerdetails.name from flight,booking,airport a1, airport a2,passengerdetails 
            WHERE booking.flight_id = flight.flight_id AND flight.from_a = a1.airport_id AND flight.to_a = a2.airport_id 
            AND passengerdetails.passenger_id = booking.passenger_id AND flight.flight_id ='$flight_id' 
            AND booking.passenger_id ='$passenger_id' AND booking_id = '$booking_id' ");
            $statement = $conexion->prepare($sql);
            $statement->execute();
            $resultado=$statement->fetchAll(PDO::FETCH_ASSOC);
            return $resultado;
        } catch (PDOException $ex) {
            echo "<strong>ERROR: </strong> ". $ex->getMessage();
        }
    }

    function dameReservas1($idPasajero){

        global $conexion;
        try {
            $sql = ("SELECT a1.name origen,a2.name destino,flight.flight_id,flight.flightno,flight.from_a,flight.to_a,flight.departure,
                        flight.arrival,flight.airline_id, flight.airplane_id , booking.booking_id, booking.seat from 
                        flight,booking,airport a1, airport a2 WHERE booking.flight_id = flight.flight_id AND 
                        flight.from_a = a1.airport_id AND flight.to_a = a2.airport_id AND passenger_id = '$idPasajero'");
            $statement = $conexion->prepare($sql);
            $statement->execute();
            $resultado = $statement->fetchAll(PDO::FETCH_ASSOC);
            return $resultado;
        } catch (PDOException $ex) {
            echo "<strong>ERROR: </strong> " . $ex->getMessage();
        }
    }


?>